# Route experiment - raw outputs (m = 30)

Raw outputs of a controlled decision experiment: 20 language models, each queried at a higher and a lower reasoning setting
(40 arms), each answering the same 3,000 route decisions. Provided for the review of an anonymous submission.

## The task

Each decision shows the travel-time estimates of 30 equally reliable forecasters for two routes, A and B, and asks the model to
choose the shorter route and reply with a JSON object `{"route": "A" or "B", "comments": "..."}`. Each decision is one API call,
with no system prompt and no conversation history. The 3,000 decisions are 1,000 at each pairwise forecaster correlation
r = 0.999, 0.99 and 0.95; at each level 500 are training decisions and 500 are evaluation decisions. The forecasts (rounded to three
decimals), their display order, the exchange of the two route labels, and the order of the schedule are all generated from one seed
(202609120410, NumPy `default_rng`); the same 3,000 prompts went to every arm. The arithmetic-mean benchmark is the route whose 30
displayed forecasts have the shorter mean. Thirty-eight arms were collected from 12 to 19 September 2026 and the two Grok 4.7 arms
from 2 to 4 October 2026.

## Files

Three zips, one per kind of file; each also holds this README and `SHA256SUMS.txt` (the checksum of every unzipped file).

- `calls/route_agent_calls_<tag>.csv` - one row per API call, 27 columns. The file is append-only: a decision whose response failed
  or could not be parsed was asked again, so a few files have more rows than decisions; every analysis uses the LAST row of each `id`.
- `thinking/route_agent_thinking_<tag>.txt` - for every call, a block that opens with a line of `=` signs and a JSON header (`id`,
  `r`, `split`, `attempt`, `model`, the setting, `status`, token counts, `route_as_shown`, `model_version`), then `--- thinking ---`
  with the thinking text the provider returned for that call (`(none returned)` when it returned none), then `--- raw output ---`
  with the model's reply as received. The thinking text is what each provider chose to return (often a summary), not necessarily
  the model's full internal reasoning.
- `run_logs/route_agent_run_log_<tag>.jsonl` - the collector's log, one JSON object per line: `run_start` records (model, settings,
  seed, sizes, output file names), one `agent_call` record per API call (including failed attempts; with the raw output and the
  thinking text), and `run_end` records. The ONLY change from the original logs: absolute directory paths in `output_file` and
  `thinking_file` were reduced to bare file names.

### Columns of the calls CSVs

| column | meaning |
|---|---|
| `seq` | row number in the file |
| `ts_utc` | time of the call (UTC) |
| `id` | the decision (correlation-level index, split, number) |
| `r` | the forecasters' pairwise correlation |
| `split` | `train` or `eval` |
| `agent_input_json` | the decision as generated: the 30 forecasts as displayed (`shown`), `display_order`, `route_labels_swapped`, the generator's latent values, and the routes picked by the reference rules |
| `agent_output_json` | the model's parsed JSON reply |
| `route_as_shown` | the route the model chose, as labelled on screen |
| `route_canonical_A1` | 1 if the chosen route is the underlying route A after undoing any label exchange, else 0 |
| `comments` | the model's comments |
| `rule_average`, `rule_forecaster_1`, `rule_first_displayed`, `rule_sign_majority` | the underlying route (1 = A) picked by the arithmetic mean, by forecaster 1, by the first displayed forecaster, and by the majority of the forecasters' signs |
| `majority_tie` | 1 if the sign majority is tied |
| `agree_average`, `agree_forecaster_1`, `agree_first_displayed`, `agree_sign_majority` | 1 if the model's choice equals that rule's |
| `status` | `delivered` or `FAILED` (a failed attempt; the decision was asked again) |
| `attempts`, `finish_reason` | attempts used; the provider's finish reason |
| `model_version` | the model as reported by the provider, with the setting |
| `input_tokens`, `thinking_tokens`, `output_tokens` | as reported by the provider (blank where it reported none) |
| `elapsed_sec` | the call's duration |

## The 40 arms

"rows" = rows in the calls CSV; "decisions" = distinct `id`s; "delivered" = decisions whose last row is `delivered`.
The lower-setting types are: off = reasoning disabled; adaptive floor = the lowest setting of a model whose reasoning cannot be
disabled; fixed floor = a fixed token budget; transitional adaptive floor = an adaptive floor that reasons at length on only part of
the decisions; other served model = a separately served non-reasoning variant.

| provider | model | setting | role | file tag | rows | decisions | delivered |
|---|---|---|---|---|---|---|---|
| Google | Gemini 3.8 Flash | high | higher | `gemini_38flash_high_m30_v4` | 3000 | 3000 | 3000 |
| Google | Gemini 3.8 Flash | low | lower (adaptive floor) | `gemini_38flash_low_m30_v5` | 3000 | 3000 | 3000 |
| Google | Gemini 3.5 Flash | high | higher | `gemini_35flash_high_m30_v8` | 3000 | 3000 | 3000 |
| Google | Gemini 3.5 Flash | minimal | lower (off) | `gemini_35flash_minimal_m30_v8` | 3000 | 3000 | 3000 |
| Google | Gemini 3.5 Flash-Lite | high | higher | `gemini_35flashlite_high_m30_v7` | 3000 | 3000 | 3000 |
| Google | Gemini 3.5 Flash-Lite | minimal | lower (off) | `gemini_35flashlite_minimal_m30_v7` | 3000 | 3000 | 3000 |
| Google | Gemini 2.5 Flash | dynamic | higher | `gemini_25flash_dynamic_m30_v6` | 3000 | 3000 | 3000 |
| Google | Gemini 2.5 Flash | budget 0 | lower (off) | `gemini_25flash_budget0_m30_v6` | 3000 | 3000 | 3000 |
| Google | Gemini 2.5 Pro | budget 32768 | higher | `gemini_25pro_budget32768_m30_v9` | 3000 | 3000 | 3000 |
| Google | Gemini 2.5 Pro | budget 128 | lower (fixed floor) | `gemini_25pro_budget128_m30_v9` | 3000 | 3000 | 3000 |
| OpenAI | GPT-6 Astra | high | higher | `gpt6astra_high_m30_v1` | 3000 | 3000 | 3000 |
| OpenAI | GPT-6 Astra | low | lower (adaptive floor) | `gpt6astra_low_m30_v1` | 3000 | 3000 | 3000 |
| OpenAI | GPT-5.6 Sol | high | higher | `gpt56sol_high_m30_v1` | 3000 | 3000 | 3000 |
| OpenAI | GPT-5.6 Sol | none | lower (off) | `gpt56sol_none_m30_v1` | 3000 | 3000 | 3000 |
| OpenAI | GPT-5.6 Terra | high | higher | `gpt56terra_high_m30_v1` | 3000 | 3000 | 3000 |
| OpenAI | GPT-5.6 Terra | none | lower (off) | `gpt56terra_none_m30_v1` | 3000 | 3000 | 3000 |
| OpenAI | GPT-5.4 mini | high | higher | `gpt54mini_high_m30_v1` | 3000 | 3000 | 3000 |
| OpenAI | GPT-5.4 mini | none | lower (off) | `gpt54mini_none_m30_v1` | 3000 | 3000 | 3000 |
| OpenAI | GPT-5.1 | high | higher | `gpt51_high_m30_v1` | 3000 | 3000 | 3000 |
| OpenAI | GPT-5.1 | none | lower (off) | `gpt51_none_m30_v1` | 3000 | 3000 | 3000 |
| Anthropic | Claude Fable 5.1 | high | higher | `fable51_high_m30_v1` | 3000 | 3000 | 3000 |
| Anthropic | Claude Fable 5.1 | low | lower (adaptive floor) | `fable51_low_m30_v1` | 3000 | 3000 | 3000 |
| Anthropic | Claude Opus 5 | high | higher | `opus5_high_m30_v1` | 3000 | 3000 | 3000 |
| Anthropic | Claude Opus 5 | disabled | lower (off) | `opus5_none_m30_v1` | 3000 | 3000 | 3000 |
| Anthropic | Claude Opus 4.6 | high | higher | `opus46_high_m30_v1` | 3000 | 3000 | 3000 |
| Anthropic | Claude Opus 4.6 | omitted | lower (off) | `opus46_none_m30_v1` | 3005 | 3000 | 2999 |
| Anthropic | Claude Sonnet 4.6 | high | higher | `sonnet46_high_m30_v1` | 3000 | 3000 | 3000 |
| Anthropic | Claude Sonnet 4.6 | omitted | lower (off) | `sonnet46_none_m30_v1` | 3002 | 3000 | 3000 |
| Anthropic | Claude Haiku 4.5 | high | higher | `haiku45_high_m30_v1` | 3000 | 3000 | 3000 |
| Anthropic | Claude Haiku 4.5 | omitted | lower (off) | `haiku45_none_m30_v1` | 3000 | 3000 | 3000 |
| xAI | Grok 4.20 (two served models) | reasoning variant | higher | `grok420_reasoning_m30_v1` | 3002 | 3000 | 3000 |
| xAI | Grok 4.20 (two served models) | non-reasoning variant | lower (other served model) | `grok420_nonreasoning_m30_v1` | 3000 | 3000 | 3000 |
| xAI | Grok 4.3 | high | higher | `grok43_high_m30_v1` | 3000 | 3000 | 3000 |
| xAI | Grok 4.3 | none | lower (off) | `grok43_none_m30_v1` | 3000 | 3000 | 3000 |
| xAI | Grok 4.5 | high | higher | `grok45_high_m30_v1` | 3002 | 3000 | 3000 |
| xAI | Grok 4.5 | low | lower (transitional adaptive floor) | `grok45_low_m30_v1` | 3000 | 3000 | 3000 |
| xAI | Grok 4.6 | high | higher | `grok46_high_m30_v1` | 3004 | 3000 | 3000 |
| xAI | Grok 4.6 | low | lower (adaptive floor) | `grok46_low_m30_v1` | 3000 | 3000 | 3000 |
| xAI | Grok 4.7 | high | higher | `grok47_high_m30_v1` | 3000 | 3000 | 3000 |
| xAI | Grok 4.7 | low | lower (adaptive floor) | `grok47_low_m30_v1` | 3003 | 3000 | 3000 |
